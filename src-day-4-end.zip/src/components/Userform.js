import React from 'react';
//component
export default class Userform extends React.Component {
    constructor() {
        super();
        this.state = {
            user: {
                name: 'Ram'
            }
        };
    }
    render() {
        return (
            <div>
                <input onChange={this.update = this.update.bind(this)} value={this.state.user.name}></input>
                <input onChange={this.updateAge = this.updateAge.bind(this)} value={this.state.user.age}></input>
                <div>
                    <input type='radio' onChange={this.updateGender=this.updateGender.bind(this)} value='Male' name='gender'/> Male
                <input type='radio' onChange={this.updateGender=this.updateGender.bind(this)} value='Female' name='gender'/>Female
                </div>
                <button onClick={this.save = this.save.bind(this)}>save</button>
            </div>
        )
    }
    updateGender(event){
        this.setState({
            user: {
                gender:event.target.value,
                name: this.state.user.name,
                age: this.state.user.age
            }
        })
    }
    updateAge(event) {
        this.setState({
            user: {
                gender: this.state.user.gender,
                name: this.state.user.name,
                age: event.target.value
            }
        })
    }
    update(event) {
        this.setState({
            user: {
                gender: this.state.user.gender,
                age: this.state.user.age,
                name: event.target.value
            }
        })
    }
    save() {
        console.log(this.state.user.name, this.state.user.age, this.state.user.gender);
    }
}
// export default function Userform(){
//     return (
//         <div> Userform </div>
//     )
// }
