import React from 'react';
import Userform from "./Userform";
//component
export default function Container() {
    return (
        <div>
            <Userform></Userform>
          
        </div>
    )
}