import React from 'react';
import {
    BrowserRouter as Router,
    Switch, useRouteMatch,
    Route, useParams,
    Link
} from "react-router-dom";
import Userform from "./Userform";
//component
export default function Container() {
    return (
        <Router>
            <div>
                <nav>
                    <ul>
                        <li>
                            <Link to="/">Home</Link>
                        </li>
                        <li>
                            <Link to="/userform">Userform</Link>
                        </li>
                        <li>
                            <Link to="/about/value1/value2">About</Link>
                        </li>
                    </ul>
                </nav>

                {/* A <Switch> looks through its children <Route>s and
            renders the first one that matches the current URL. */}
                <Switch>
                    <Route path="/userform">
                        <Userform />
                    </Route>
                    <Route path="/about/:param1/:param2">
                        <About />
                    </Route>
                    <Route path="/">
                        <Home />
                    </Route>
                </Switch>
            </div>
        </Router>
    )
}
function About() {
    let match = useRouteMatch();
    // console.log(match);
    const params = useParams();
    console.log(params);
    
    return <h2>About</h2>;
}
function Home() {
    let match = useRouteMatch();
    console.log(match);
    
    return <h2>Home</h2>;
}
function Child() {
    let match = useRouteMatch();
    console.log(match);
    
    return <h2>Home</h2>;
}