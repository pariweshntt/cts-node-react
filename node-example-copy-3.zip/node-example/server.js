const basics_module = require('./basics');
// console.log(basics_module);
// basics_module.ctsreadfile1('read.txt');

basics_module.ctsWritefile('./output/output.txt', 'this is some text111', function
    (error) {
    if (error) {
        console.log(error);
    }
});