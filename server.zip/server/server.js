const express = require('express');
const basics = require('./basics');
const app = express();
const port = 3000

app.get('/', function (request, response) {
    console.log(request.url);
    response.send('Hello World!')
});
app.get('/readfile', function (request, response) {
    basics.ctsreadfile1('response.txt', function(error, data){
        // response.setHeader('Content-Type','html/text');
        response.send(data.toString());
    })
});
app.get('/order', function (request, response) {
    console.log('headers=', request.headers['accept-language']);
    console.log('query=', request.query.param2);
    response.send('ordered')
});
app.listen(port, function() {
    console.log(`Example app listening on port ${port}!`)
});