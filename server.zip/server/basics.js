const os = require('os');
// console.log(os.arch());
// alert('are');
const fs = require('fs');
function ctsreadfile(filepath, callback) {
    if (callback) {
        fs.readFile(filepath, callback);
    } else {
        fs.readFile(filepath, function (error1, data) {
            if (error1) {
                console.log(error1);
            }
            else {
                console.log(data.toString());
            }
            // return data;
        });
    }
}
function ctsWritefile(filepath, data) {
    fs.writeFile(filepath, data, function (error1) {
        if (error1) {
            console.log(error1);
        }
    });
}

function copy(source, destination) {
    ctsreadfile(source, function(error1, data){
        if (error1) {
            console.log(error1);
        }
        else {
            ctsWritefile(destination, data, function
                (error) {
                if (error) {
                    console.log(error);
                }
            });
        }
    });
}
module.exports = {
    ctsWritefile: ctsWritefile,
    ctsreadfile1: ctsreadfile
}
