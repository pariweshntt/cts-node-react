const os = require('os');
// console.log(os.arch());
// alert('are');
const fs = require('fs');
function ctsreadfile(filepath){
    fs.readFile(filepath, function(error1, data){
        if(error1){
            console.log(error1);
        }
        else{
            console.log(data.toString());
        }
    });
}
module.exports={
    ctsreadfile1:ctsreadfile
}
console.log('1');
// for(;;){

// }