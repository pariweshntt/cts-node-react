const basics_module = require('./basics');
console.log(basics_module);
basics_module.ctsreadfile1('read.txt');
