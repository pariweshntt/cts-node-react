import React from 'react';
//stateless component
// export default function Counter(props){
//     return (<div>
//         <span >{props.count}</span>
//     </div>)
// }

export default class Counter extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (<div>
            <span >{this.props.count}</span>
        </div>)
    }
}